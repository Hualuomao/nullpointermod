package com.example.nullpointermod.item;

import com.example.nullpointermod.NullPointerMod;
import com.example.nullpointermod.entity.NullPointerProjectile;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

public class NullPointerItem extends Item {
    public NullPointerItem() {
        super(new Properties().stacksTo(1));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack heldStack = player.getItemInHand(hand);

        if (level.isClientSide()) {
            // 客户端播放声音反馈
            level.playSound(player, player.getX(), player.getY(), player.getZ(), SoundEvents.SNOWBALL_THROW, SoundSource.PLAYERS, 0.5F, 0.4F);
            return InteractionResultHolder.success(heldStack);
        }

        NullPointerProjectile projectile = new NullPointerProjectile(level, player);
        projectile.setPos(player.getX(), player.getEyeY() - 0.1, player.getZ());
        projectile.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 1.5F, 1.0F);
        level.addFreshEntity(projectile);

        heldStack.shrink(1); // 消耗自身
        player.getCooldowns().addCooldown(this, 20); // 1秒冷却

        return InteractionResultHolder.success(heldStack);
    }
}
