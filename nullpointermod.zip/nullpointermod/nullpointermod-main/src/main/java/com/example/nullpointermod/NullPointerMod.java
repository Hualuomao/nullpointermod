package com.example.nullpointermod;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.server.ServerLifecycleHooks;

import com.example.nullpointermod.entity.NullPointerProjectile;
import com.example.nullpointermod.item.JavaItem;
import com.example.nullpointermod.item.NullPointerItem;
import com.example.nullpointermod.network.ClientboundCrashPacket;

import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(NullPointerMod.MOD_ID)
public class NullPointerMod {
    public static final String MOD_ID = "nullpointermod";
    public static final String MOD_VERSION = "1.1.0";
    private static final String PROTOCOL_VERSION = "1.0";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(MOD_ID, "main"),
        () -> PROTOCOL_VERSION,
        PROTOCOL_VERSION::equals,
        PROTOCOL_VERSION::equals
    );

    public static final Logger LOGGER = LogManager.getLogger();

    // 注册物品
    private static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final RegistryObject<Item> NULL_POINTER_ITEM = ITEMS.register("java_null_pointer_exception", NullPointerItem::new);
    public static final RegistryObject<Item> JAVA_ITEM = ITEMS.register("java_item", JavaItem::new);

    // 注册实体
    private static final DeferredRegister<net.minecraft.world.entity.EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MOD_ID);
    public static final RegistryObject<net.minecraft.world.entity.EntityType<NullPointerProjectile>> NULL_POINTER_PROJECTILE =
        ENTITIES.register("null_pointer_projectile",
            () -> net.minecraft.world.entity.EntityType.Builder.<NullPointerProjectile>of(NullPointerProjectile::new, net.minecraft.world.entity.MobCategory.MISC)
                .sized(0.25F, 0.25F)
                .clientTrackingRange(4)
                .updateInterval(20)
                .build("null_pointer_projectile")
        );

    public NullPointerMod() {
        var modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(modEventBus);
        ENTITIES.register(modEventBus);

        // 注册网络包（索引0）
        CHANNEL.registerMessage(0, ClientboundCrashPacket.class,
            ClientboundCrashPacket::encode,
            ClientboundCrashPacket::decode,
            ClientboundCrashPacket::handle
        );

        // 注册服务端事件（扫描容器）
        MinecraftForge.EVENT_BUS.register(this);

        LOGGER.info("NullPointerMod v{} initializing for Minecraft 1.20.1 / Forge (recommended).", MOD_VERSION);
    }

    // ---------- 定时扫描容器，销毁非法存放的空指针（世界容器，跳过末影箱） ----------
    private static int tickCounter = 0;

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            tickCounter++;
            if (tickCounter % 20 == 0) { // 每秒一次
                scanAndCleanContainers();
            }
        }
    }

    private void scanAndCleanContainers() {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;

        for (ServerLevel level : server.getAllLevels()) {
            // 遍历方块实体，清理除末影箱以外的容器内的 null pointer
            for (BlockEntity be : level.getBlockEntities().values()) {
                // 跳过末影箱（合法存放）
                if (be instanceof EnderChestBlockEntity) continue;

                if (be instanceof Container container) {
                    boolean changed = false;
                    for (int slot = 0; slot < container.getContainerSize(); slot++) {
                        ItemStack stack = container.getItem(slot);
                        if (!stack.isEmpty() && stack.getItem() == NULL_POINTER_ITEM.get()) {
                            container.setItem(slot, ItemStack.EMPTY);
                            changed = true;
                        }
                    }
                    if (changed) {
                        be.setChanged();
                        // 通知客户端更新方块状态
                        level.sendBlockUpdated(be.getBlockPos(), be.getBlockState(), be.getBlockState(), 3);
                        LOGGER.info("Removed NullPointer items from container at {} in {}", be.getBlockPos(), level.dimension().location());
                    }
                }
            }
        }
    }
}
